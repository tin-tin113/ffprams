# MODULE 3: GEO-MAPPING & DATA VISUALIZATION MODULE
## Complete Project Management Deliverables

**Course**: Project Management
**Assignment**: Module Analysis with ERD, DFD (Level 0-4), and Use Case UML
**Deadline**: April 14, 2026, 12:00 NN
**Module**: Geo-Mapping & Data Visualization
**Date Created**: 2026-04-15

---

## 1. ENTITY-RELATIONSHIP DIAGRAM (ERD)

### ERD Narrative

**Primary Entity**: GeoLocation Data
- Combines beneficiary locations, distribution sites, and program coverage
- Links geographic data (latitude/longitude) with program metrics
- Enables visualization on maps and dashboard analytics

**Core Entities**:
- **Barangays**: Geographic boundaries with geocoordinates
- **Beneficiary Locations**: Individual beneficiary GPS points
- **Distribution Points**: Event venues with capacity and access info
- **Heatmaps**: Aggregated density data for regions
- **Dashboards**: User-defined visualization configurations
- **Analytics Data**: Computed statistics by geography

### ERD Diagram (Crow's Foot Notation)

```
┌────────────────────────────────────────────────────────────────┐
│           GEO-MAPPING & DATA VISUALIZATION ERD                 │
└────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────┐
│  BARANGAYS (Geographic Regions)      │
├──────────────────────────────────────┤
│ PK  id                               │
│     name                             │
│     municipality / city              │
│     province                         │
│     region                           │
│     latitude (center point)          │
│     longitude (center point)         │
│     boundary_polygon (JSON/GeoJSON)  │
│     area_sqkm                        │
│     population_estimate              │
│     households_estimate              │
│     beneficiaries_count              │
│     programs_active                  │
│     created_at, updated_at           │
└──────────────┬──────────────────────┘
               │ (1:M)
               │ contains
               │
┌──────────────v──────────────────────────────────┐
│  BENEFICIARY_LOCATIONS (Individual Points)      │
├──────────────────────────────────────────────────┤
│ PK  id                                          │
│ FK  beneficiary_id                              │
│ FK  barangay_id                                 │
│     latitude (decimal)                          │
│     longitude (decimal)                         │
│     address (geocoded)                          │
│     street_name / sitio                         │
│     gps_accuracy_meters                         │
│     last_verified_date                          │
│     location_confirmed_by_user                  │
│     created_at, updated_at                      │
└──────────────┬──────────────────────────────────┘
               │ (1:M relationship to beneficiaries)
               │
        ┌──────────────────────┐
        │  BENEFICIARIES       │
        │  (Module 1 Link)     │
        ├──────────────────────┤
        │ id                   │
        │ full_name            │
        │ classification       │
        │ status               │
        └──────────────────────┘

┌────────────────────────────────────────────────┐
│  DISTRIBUTION_POINTS (Venue Locations)         │
├────────────────────────────────────────────────┤
│ PK  id                                         │
│ FK  barangay_id                                │
│     name / venue_name                          │
│     latitude                                   │
│     longitude                                  │
│     address                                    │
│     capacity_people                            │
│     capacity_items                             │
│     contact_person / phone                     │
│     accessibility_rating                       │
│     coverage_radius_km                         │
│ FK  event_id (nullable)                        │
│     active                                     │
│     created_at, updated_at                     │
└────────────────────────────────────────────────┘

┌────────────────────────────────────────────────┐
│  HEATMAP_DATA (Aggregated Density)             │
├────────────────────────────────────────────────┤
│ PK  id                                         │
│ FK  barangay_id                                │
│     metric_type (Beneficiaries/Resources/     │
│                  Allocations/Events)          │
│     period (Monthly/Quarterly/Yearly)          │
│     period_date (YYYY-MM or YYYY-MM-DD)        │
│     density_score (0-100)                      │
│     count_value                                │
│     percentage_of_total                        │
│     change_from_previous (%)                   │
│     data_computed_at                           │
│     valid_until                                │
└────────────────────────────────────────────────┘

┌────────────────────────────────────────────────┐
│  DASHBOARD_CONFIGS (User Visualizations)       │
├────────────────────────────────────────────────┤
│ PK  id                                         │
│ FK  user_id (creator)                          │
│     dashboard_name                             │
│     description                                │
│     dashboard_type (Map/Chart/Report)          │
│     layout_configuration (JSON)                │
│     filters_applied (JSON)                     │
│     map_center_lat / map_center_lon            │
│     map_zoom_level                             │
│     selected_layers:                           │
│       • Beneficiaries (bool)                   │
│       • Distribution Points (bool)             │
│       • Heatmaps (bool)                        │
│       • Events (bool)                          │
│     color_scheme                               │
│     refresh_interval_seconds                   │
│     is_public (bool)                           │
│     saved_count (times accessed)               │
│     created_at, updated_at                     │
└────────────────────────────────────────────────┘

┌────────────────────────────────────────────────┐
│  ANALYTICS_CACHE (Pre-computed Statistics)     │
├────────────────────────────────────────────────┤
│ PK  id                                         │
│ FK  barangay_id                                │
│     metric_name (e.g., 'beneficiary_count')    │
│     metric_value                               │
│     metric_percentile (0-100)                  │
│     benchmark_value (regional average)         │
│     performance_rating (Excellent/Good/Poor)   │
│     period_date                                │
│     last_computed_at                          │
│     cache_valid_until                         │
└────────────────────────────────────────────────┘

┌────────────────────────────────────────────────┐
│  MAP_LAYERS (Visualization Configurations)     │
├────────────────────────────────────────────────┤
│ PK  id                                         │
│     layer_name                                 │
│     layer_type (Point/Polygon/Heatmap)         │
│     data_source (Beneficiaries/Events/etc)     │
│     icon_type / marker_style                   │
│     color_code                                 │
│     opacity (0-1)                              │
│     visibility_threshold_zoom                  │
│     enabled_by_default (bool)                  │
│     load_order (priority)                      │
│     created_at                                 │
└────────────────────────────────────────────────┘

┌────────────────────────────────────────────────┐
│  GEOCODING_LOG (API Call History)              │
├────────────────────────────────────────────────┤
│ PK  id                                         │
│     address_input                              │
│     latitude_result / longitude_result         │
│     accuracy_level                             │
│     provider (Google/OpenStreetMap/etc)        │
│     cost_units (API credit consumed)           │
│     request_date                               │
│     beneficiary_id (nullable)                  │
│     created_at                                 │
└────────────────────────────────────────────────┘
```

---

## 2. DATA FLOW DIAGRAM (DFD) - ALL LEVELS

### DFD LEVEL 0 - SYSTEM CONTEXT

```
┌────────────────────────────────────────────────────────┐
│         SYSTEM BOUNDARY: FFPRAMS                       │
│                                                         │
│     GEO-MAPPING & DATA VISUALIZATION MODULE            │
│                                                         │
└────────────────────────────────────────────────────────┘
          ▲                                    ▲
          │                                    │
    User Queries                    Map/GIS Services
    Dashboard Views                 Geocoding APIs
    Filters & Reports               Mapping Libraries
          │                                    │
          │                                    │
    ┌─────────────────────────────────────────────────┐
    │                                                 │
    │  • Render Interactive Maps                      │
    │  • Compute Heatmaps                             │
    │  • Generate Analytics                           │
    │  • Create Dashboard Views                       │
    │  • Process Geocoding Requests                   │
    │  • Export Reports                               │
    │                                                 │
    └──────────────────┬────────────────────┬─────────┘
                       │                    │
         DATABASE      │                    │  EXTERNAL
         OPERATIONS    │                    │  APIs
                       ▼                    ▼
        ┌──────────────────────────────────────────┐
        │  CACHE & ANALYTICS ENGINE                │
        │                                          │
        │  • Heatmap computation                   │
        │  • Analytics aggregation                 │
        │  • Dashboard caching                     │
        │                                          │
        └─────────────┬────────────────────────────┘
                      │
                      ▼
        ┌──────────────────────────────────────────┐
        │  POSTGRESQL DB TABLES:                   │
        │  • barangays (geo_spatial)               │
        │  • beneficiary_locations                 │
        │  • distribution_points                   │
        │  • heatmap_data                          │
        │  • dashboard_configs                     │
        │  • analytics_cache                       │
        │  • map_layers                            │
        │  • geocoding_log                         │
        │  • view_access_logs                      │
        └──────────────────────────────────────────┘
```

### DFD LEVEL 1 - MAIN PROCESSES

```
MAIN PROCESSES:
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│       P3.1       │  │       P3.2       │  │       P3.3       │
│   FETCH & RENDER │  │  COMPUTE & CACHE │  │  GENERATE        │
│     MAPS         │  │   ANALYTICS      │  │  ANALYTICS       │
│                  │  │                  │  │  DASHBOARD       │
└──────────────────┘  └──────────────────┘  └──────────────────┘

┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│       P3.4       │  │       P3.5       │  │       P3.6       │
│    PROCESS       │  │    GENERATE      │  │    EXPORT        │
│   GEOCODING      │  │    HEATMAPS      │  │    REPORTS       │
│                  │  │                  │  │                  │
└──────────────────┘  └──────────────────┘  └──────────────────┘
```

**P3.1: FETCH & RENDER INTERACTIVE MAP**
- Input: Dashboard config, user filters, zoom level
- Processing: Query locations (beneficiaries, events, points)
- Output: GeoJSON features, rendered map with markers
- Data Stores: barangays, beneficiary_locations, distribution_points

**P3.2: COMPUTE & CACHE ANALYTICS**
- Input: Period (monthly), metric type (beneficiaries, allocations)
- Processing: Aggregate data by barangay, compute percentiles
- Output: Cached analytics results
- Data Stores: analytics_cache, heatmap_data

**P3.3: GENERATE ANALYTICS DASHBOARD**
- Input: User dashboard config, date filters
- Processing: Combine map + analytics + charts
- Output: Dashboard HTML/JSON
- Data Stores: dashboard_configs, analytics_cache

**P3.4: PROCESS GEOCODING REQUEST**
- Input: Address or beneficiary GPS update
- Processing: Call geocoding API, validate coordinates
- Output: Latitude/longitude, geocoding_log entry
- Data Stores: beneficiary_locations, geocoding_log

**P3.5: GENERATE HEATMAPS**
- Input: Beneficiary locations, event distributions
- Processing: Convert points to density grid
- Output: Heatmap layer GeoJSON
- Data Stores: heatmap_data

**P3.6: EXPORT REPORTS**
- Input: Report type (PDF/Excel), filters
- Processing: Generate charts/tables from cached analytics
- Output: PDF/Excel file
- Data Stores: analytics_cache (read-only)

---

### DFD LEVEL 2 - RENDER MAP (P3.1) DECOMPOSITION

```
P3.1 DECOMPOSITION: FETCH & RENDER INTERACTIVE MAP

Input: dashboard_config, user_filters, zoom_level

Step 1: Parse Dashboard Configuration
──────────────────────────────────────
Query dashboard_configs (D31):
  SELECT * WHERE config_id = user_dashboard_id

Extract:
  • map_center (lat, lon)
  • zoom_level
  • enabled_layers []
  • applied_filters {}
  • color_scheme

Step 2: Apply User Filters
──────────────────────────
Filters may include:
  • Barangay selection
  • Date range (events/allocations)
  • Beneficiary classification
  • Resource type (if showing allocations)
  • Status filter (active/inactive)

Step 3: Fetch Barangay Boundaries
─────────────────────────────────
Query barangays (D25):
  SELECT id, name, boundary_polygon, lat, lon
  WHERE id IN (selected_barangays)

Convert to GeoJSON Feature Collection:
  {
    "type": "FeatureCollection",
    "features": [
      {
        "type": "Feature",
        "geometry": {
          "type": "Polygon",
          "coordinates": [[...boundary coords...]]
        },
        "properties": {
          "barangay_id": 123,
          "name": "San Juan"
        }
      }
    ]
  }

Step 4: Fetch Beneficiary Location Points
──────────────────────────────────────────
IF 'Beneficiaries' layer enabled:
  Query beneficiary_locations (D26):
    SELECT benef_loc.*, beneficiaries.full_name,
           beneficiaries.classification
    WHERE benef_loc.barangay_id IN (selected_barangays)
    AND beneficiaries.status = 'active'
    LIMIT 5000  // performance limit per map view

  Convert to GeoJSON Point Features:
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [lon, lat]
      },
      "properties": {
        "name": "Juan Cruz",
        "classification": "Farmer",
        "icon": "farmer-icon.png",
        "color": "#2196F3"  // blue
      }
    }

Step 5: Fetch Distribution Point Markers
────────────────────────────────────────
IF 'Distribution Points' layer enabled:
  Query distribution_points (D27):
    SELECT * WHERE barangay_id IN (selected_barangays)
    AND active = true

  Convert to GeoJSON Props:
    Properties include:
      • name
      • capacity
      • accessibility_rating
      • icon (venue-type specific)

Step 6: Fetch & Render Heatmap Layer
────────────────────────────────────
IF 'Heatmaps' layer enabled:
  Query heatmap_data (D28):
    SELECT * WHERE period_date = current_month
    AND metric_type = selected_metric

  Render as Leaflet/Mapbox heatmap layer
  Opacity by density_score (0-100)

Step 7: Combine All Layers
──────────────────────────
Create master GeoJSON:
  {
    "barangays": {...},
    "beneficiaries": {...},
    "distribution_points": {...},
    "heatmaps": {...}
  }

Step 8: Create Map Configuration
────────────────────────────────
Config Object:
  {
    "center": [map_center_lat, map_center_lon],
    "zoom": zoom_level,
    "layers": [
      { "name": "Beneficiaries", "visible": true, "data": {...} },
      { "name": "Distribution Points", "visible": true, "data": {...} },
      { "name": "Heatmap", "visible": true, "data": {...} }
    ],
    "baseMap": "osm",  // OpenStreetMap
    "attribution": "..."
  }

Step 9: Render Interactive Map
──────────────────────────────
Use Leaflet.js or Mapbox GL JS:
  • Display basemap
  • Add all feature layers
  • Attach click handlers for popups
  • Enable zoom/pan controls
  • Show legend

Step 10: Return Map HTML/JSON
–────────────────────────────
RETURN: Rendered map div or JSON structure
        ready for client-side rendering
```

---

### DFD LEVEL 3 - COMPUTE ANALYTICS (P3.2) DECOMPOSITION

```
P3.2 DECOMPOSITION: COMPUTE & CACHE ANALYTICS

Input: period (e.g., '2026-04'), metric_type ('beneficiaries')

Step 1: Query Period Configuration
──────────────────────────────────
Determine date range:
  IF period = 'monthly':
    start_date = 2026-04-01
    end_date = 2026-04-30
  IF period = 'quarterly':
    start_date, end_date accordingly

Step 2: Query Aggregation by Barangay
─────────────────────────────────────
IF metric_type = 'beneficiaries':
  FOR each barangay:
    count = SELECT COUNT(*) FROM beneficiaries
            WHERE barangay_id = current_barangay
            AND status = 'active'
            AND created_at <= end_date

IF metric_type = 'allocations_distributed':
  FOR each barangay:
    count = SELECT COUNT(DISTINCT allocation_id)
            FROM allocations
            WHERE beneficiary.barangay = current_barangay
            AND status = 'Distributed'
            AND distribution_date BETWEEN start & end

IF metric_type = 'resources_distributed':
  FOR each barangay:
    qty = SELECT SUM(received_quantity)
          FROM allocations
          WHERE beneficiary.barangay = current_barangay
          AND status = 'Distributed'
          AND distribution_date BETWEEN start & end

Step 3: Calculate Percentiles
─────────────────────────────
Sort barangays by metric value:
  RANK barangays by count/qty (descending)

Compute percentiles:
  FOR each barangay:
    percentile = (rank / total_barangays) * 100
    rating = CASE WHEN percentile >= 75 THEN 'Excellent'
                  WHEN percentile >= 50 THEN 'Good'
                  WHEN percentile >= 25 THEN 'Fair'
                  ELSE 'Needs attention' END

Step 4: Compute Regional Benchmark
──────────────────────────────────
benchmark_value = AVG(all_barangay_counts)
std_deviation = STDEV(all_barangay_counts)

Step 5: Identify Trends
──────────────────────
Query previous period (same period last year):
  previous_count = SELECT COUNT(*)
                   FROM beneficiaries
                   WHERE date BETWEEN prev_start & prev_end

change_percent = ((current - previous) / previous) * 100
trend = increase/decrease/stable

Step 6: Store in Analytics Cache
────────────────────────────────
INSERT INTO analytics_cache:
  FOR each barangay:
    • barangay_id
    • metric_name ('beneficiaries_count')
    • metric_value (count)
    • metric_percentile (0-100)
    • benchmark_value
    • performance_rating
    • change_from_previous (%)
    • period_date ('2026-04')
    • cache_valid_until (end of day current+7)

Step 7: Update Heatmap Data
──────────────────────────
INSERT INTO heatmap_data:
  FOR each barangay:
    • barangay_id
    • metric_type
    • period
    • density_score = percentile (0-100)
    • count_value = actual count
    • percentage_of_total

Step 8: Log Cache Creation
─────────────────────────
Create entry in audit_logs:
  Action: 'analytics_computed'
  Details: metric type, period, barangay_count
  Timestamp: NOW()
```

---

### DFD LEVEL 4 - COMPUTE DENSITY SCORE (Terminal Process)

```
TERMINAL PROCESS: COMPUTE DENSITY SCORE

INPUTS:
  beneficiary_locations[] (array of points with lat/lon)
  grid_size_meters (typically 1000m)
  radius_meters (search radius around grid cell)

ALGORITHM: Kernel Density Estimation
─────────────────────────────────────

Step 1: Divide Map into Grid
  Create square grid cells across barangay:
  cell_size_meters = grid_size_meters
  cell_size_degrees = meters_to_degrees(grid_size_meters)

  Grid cells: (min_lat, min_lon) to (max_lat, max_lon)

Step 2: Count Points in Each Cell
  FOR each grid_cell:
    count = 0
    FOR each beneficiary_location:
      distance = euclidean_distance(
        grid_cell.center,
        beneficiary_location
      )
      IF distance <= radius_meters:
        count += 1
    cell.point_count = count

Step 3: Find Max Count
  max_count = MAX(all_cell.point_count)

Step 4: Normalize to 0-100 Scale
  FOR each grid_cell:
    IF max_count > 0:
      density_score = (cell.point_count / max_count) * 100
    ELSE:
      density_score = 0

    ROUND(density_score, 2)

Step 5: Apply Color Mapping
  color = CASE WHEN density_score >= 75 THEN '#FF0000'  // Red (very high)
               WHEN density_score >= 50 THEN '#FF8800'  // Orange (high)
               WHEN density_score >= 25 THEN '#FFFF00'  // Yellow (medium)
               ELSE '#00FF00' END  // Green (low)

Step 6: Generate Heatmap Layer
  FOR each grid_cell with density > 0:
    CREATE GeoJSON Feature:
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [cell.lon, cell.lat]
      },
      "properties": {
        "density": density_score,
        "count": point_count,
        "color": color,
        "intensity": density_score / 100  // 0-1 for opacity
      }
    }

Step 7: Optional - Smooth with Gaussian Kernel
  FOR each grid_cell:
    smoothed_density = 0
    FOR each neighboring_cell (within 2 cells):
      distance = euclidean_distance(current_cell, neighbor)
      weight = gaussian_kernel(distance, std_dev=sigma)
      smoothed_density += neighbor.density * weight

    cell.final_density = smoothed_density

Step 8: Return Heatmap GeoJSON
  RETURN: {
    "type": "FeatureCollection",
    "features": [... all grid cells as features ...],
    "metadata": {
      "total_points": beneficiary_count,
      "grid_size_m": grid_size_meters,
      "max_density": max_density_value,
      "computed_at": NOW()
    }
  }

PSEUDOCODE:
──────────
function computeDensityScore(locations, gridSize, radius):
  grid = createGrid(boundaries, gridSize)
  maxCount = 0

  for each cell in grid:
    cell.count = 0
    for each location in locations:
      if distance(cell.center, location) <= radius:
        cell.count++
    if cell.count > maxCount:
      maxCount = cell.count

  for each cell in grid:
    cell.density = (cell.count / maxCount) * 100

  return grid
```

---

## 3. USE CASE DIAGRAM (UML)

### Use Cases

**UC1: View Interactive Map**
- Actor: Admin, Manager
- Input: Dashboard selection, map filters
- Processing: Fetch layers, render map
- Output: Interactive map with legends

**UC2: Analyze Geographic Patterns**
- Actor: Analyst, Manager
- Input: Metric type, date range, barangay filter
- Processing: Compute analytics, generate heatmap
- Output: Heatmap visualization + statistics

**UC3: Generate Analytics Dashboard**
- Actor: Manager, Supervisor
- Input: Dashboard config, refresh interval
- Processing: Combine maps + charts + analytics
- Output: Full dashboard view

**UC4: Export Report**
- Actor: Manager
- Input: Report type (PDF/Excel), filters
- Processing: Generate charts/tables
- Output: PDF or Excel file

**UC5: Manage Map Layers**
- Actor: Admin
- Input: Layer configuration
- Processing: Update map_layers table
- Output: Updated map rendering

---

## 4. PERFORMANCE CONSIDERATIONS

1. **Map Rendering**: Limit beneficiary points to 5,000 per map view
2. **Heatmap Computation**: Cache for 7 days, refresh daily
3. **Analytics Cache**: Expire after 24 hours
4. **Geocoding**: Batch requests, rate-limit API calls
5. **Database Indexes**: Create indexes on lat/lon for spatial queries

---

## 5. EXTERNAL SERVICES & INTEGRATIONS

- **Map Library**: Leaflet.js or Mapbox GL JS
- **Geocoding**: Google Maps API or OpenStreetMap Nominatim
- **Charting**: Chart.js or D3.js for analytics
- **Export**: jsPDF/ExcelJS for report generation

---

## DOCUMENT METADATA

- **Version**: 1.0
- **Status**: COMPLETE
- **Pages**: 12+ deliverable pages
- **Date**: 2026-04-15
- **For**: Project Management Assignment
